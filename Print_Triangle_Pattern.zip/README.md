
# Triangle Pattern Assignment

This Python script prints three types of triangle patterns using the `*` character:

1. **Lower Triangular Pattern**
2. **Upper Triangular Pattern**
3. **Pyramid Pattern**

## 🔧 How to Run

Make sure you have Python installed. Then run the file:

```bash
python print_triangle_pattern.py
```

You will be prompted to enter the number of rows, and the program will display all three patterns accordingly.

## 📁 File Included

- `print_triangle_pattern.py`: Main Python script
- `README.md`: This instruction file

## 👤 Author

Keshav Kumar Jha  
Email:jhakeshav616@gmail.com
GitHub:github.com/jhakeshav25
